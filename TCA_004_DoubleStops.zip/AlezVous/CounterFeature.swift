import SwiftUI
import ComposableArchitecture

@Reducer
struct CounterFeature {
    @ObservableState
    struct State: Equatable {
        var count = 0
    }
    enum Action {
        case incrementTapped
        case decrementTapped
    }
    var body: some Reducer<State, Action> {
        Reduce { state, action in
            switch action {
            case .incrementTapped:
                state.count += 1
                return .none
                
            case .decrementTapped:
                state.count -= 1
                return .none 
            }
        }
    }
}


struct CounterApp: View {
    let store: StoreOf<CounterFeature>
    
    var body: some View {
        VStack(spacing: 24) {
            Text("\(store.count)")
                .font(.largeTitle)
            
            HStack(spacing: 24) {
                Button("-") {
                    store.send(.decrementTapped)
                }
                
                Button("+") {
                    store.send(.incrementTapped)
                }
            }
        }
    }
    
}
