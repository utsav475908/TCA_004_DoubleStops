import SwiftUI
import ComposableArchitecture

@Reducer
struct DashboardFeature {
    
    @ObservableState
    struct State:Equatable {
        var counter = CounterFeature.State()
        var stopwatch = StopWatchFeature.State()
    }
    
    enum Action {
        case counter(CounterFeature.Action)
        case stopwatch(StopWatchFeature.Action)
    }
    
    var body: some Reducer<State, Action> {
        Scope(state: \.counter, action: \.counter) {
            //            LoggingReducer(
            //                reducer: CounterFeature(),
            //                label: "🧮 Counter"
            //            )
            CounterFeature()
            
        }
        
        
        
        Scope(state: \.stopwatch, action: \.stopwatch) {
            //            LoggingReducer(
            //                            reducer: StopWatchFeature(),
            //                            label: "⏱️ Stopwatch"
            //                        )
            StopWatchFeature().debugged("⏱️ Stopwatch")
        }
        
        
        Reduce{ _, action in
            // print("📊 Dashboard received:", action)
            
            return  .none
        }
        
    }
}

struct DashboardView: View {
    let store: StoreOf<DashboardFeature>
    
    var body: some View {
        // SwiftUI only
        WithViewStore(store, observe: { $0 }) { viewStore in
            let _ = Self._printChanges()
            VStack(spacing: 40) {
                CounterApp(
                    store: store.scope(
                        state: \.counter,
                        action: \.counter
                    )
                )
                Divider()
                StopwatchView(
                    store: store.scope(
                        state: \.stopwatch,
                        action: \.stopwatch
                    )
                )
            }
            .padding()
            
        }
        
    }
}

@main
struct DashboardApp: App {
    var body: some Scene {
        WindowGroup {
            DashboardView(
                store: Store(
                    initialState: DashboardFeature.State(),
                    reducer: {
                        DashboardFeature()
                        
                    }
                )
            )
        }
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        DashboardView(
            store: Store(
                initialState: DashboardFeature.State(),
                reducer: {
                    DashboardFeature()
                    
                }
            )
        )
        .preferredColorScheme(.dark)
    }
}


//@main
//struct DashboardApp: App {
//    var body: some Scene {
//        WindowGroup {
//            DashboardView(
//                store: Store(
//                    initialState: DashboardFeature.State(),
//                    reducer: {
//                        DashboardFeature()
//                    }
//                )
//            )
//        }
//    }
//}



//@main
//struct StopwatchApp: App {
//    var body: some Scene {
//        WindowGroup {
//            StopwatchView(
//                store: Store(
//                    initialState: StopWatchFeature.State(),
//                    reducer: {
//                        StopWatchFeature()
//                    }
//                )
//            )
//        }
//    }
//}





