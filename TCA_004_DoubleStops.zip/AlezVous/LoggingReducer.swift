import ComposableArchitecture

struct LoggingReducer<R: Reducer>: Reducer {
    let reducer: R
    let label: String
    
    func reduce(
        into state: inout R.State,
        action: R.Action
    ) -> Effect<R.Action> {
        print("🔹 \(label) action:", action)
        let effect = reducer.reduce(into: &state, action: action)
                //print("🔸 \(label) state:", state)
                return effect
    }
}

extension Reducer {

    func debugged(_ label: String) -> some Reducer<State, Action> {
        LoggingReducer(
            reducer: self,
            label: label
        )
    }
}
