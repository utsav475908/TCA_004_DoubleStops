
import SwiftUI
import ComposableArchitecture

struct TimerID: Sendable {
}

nonisolated extension TimerID: Hashable {
    static func == (lhs: TimerID, rhs: TimerID) -> Bool { true }
    func hash(into hasher: inout Hasher) {
        // A zero-sized type: all instances are considered identical for cancellation purposes
        hasher.combine(0)
    }
}

@Reducer
@MainActor
struct StopWatchFeature {
    @Dependency(\.continuousClock) var clock
    
    @ObservableState
    struct State: Equatable {
        var elapsedSeconds = 0
        var isRunning = false
    }
    
    enum Action {
        case startTapped
        case stopTapped
        case resetTapped
        case timerTicked
    }
    
    
    var body: some Reducer<State, Action> {
        Reduce { state, action in
            
            switch action {
            case .startTapped:
                guard !state.isRunning else { return .none}
                state.isRunning = true
                
                return .run { send in
                    for await _ in await clock.timer(interval: .seconds(1)) {
                        await send(.timerTicked)
                    }
                }
                .cancellable(id: TimerID())
                
            case .stopTapped:
                state.isRunning = false
                return .cancel(id: TimerID())
                
            case .resetTapped:
                state.elapsedSeconds = 0
                return .none
                
                
            case .timerTicked:
                state.elapsedSeconds += 1
                return .none
            }
        }
    }
}


struct StopwatchView: View {

    let store: StoreOf<StopWatchFeature>

    var body: some View {
        VStack(spacing: 32) {

            Text("\(store.elapsedSeconds)s")
                .font(.largeTitle)

            HStack(spacing: 20) {

                Button("Start") {
                    store.send(.startTapped)
                }
                .disabled(store.isRunning)

                Button("Stop") {
                    store.send(.stopTapped)
                }
                .disabled(!store.isRunning)

                Button("Reset") {
                    store.send(.resetTapped)
                }
            }
        }
        .padding()
    }
}
