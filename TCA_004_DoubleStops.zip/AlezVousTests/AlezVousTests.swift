//
//  AlezVousTests.swift
//  AlezVousTests
//
//  Created by utsav on 19/12/25.
//

import XCTest
@testable import AlezVous
import ComposableArchitecture

final class AlezVousTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
// @MainActor
//    func testTimerTicks() async {
//        let clock = TestClock()
//
//        let store = TestStore(
//            initialState: StopWatchFeature.State(),
//            reducer: {
//                StopWatchFeature()
//            }
//        ) {
//            $0.continuousClock = clock
//        }
//
//        await store.send(.startTapped) {
//            $0.isRunning = true
//        }
//
//        await clock.advance(by: .seconds(3))
//
//        await store.receive(.timerTicked) {
//            $0.elapsedSeconds = 1
//        }
//        await store.receive(.timerTicked) {
//            $0.elapsedSeconds = 2
//        }
//        await store.receive(.timerTicked) {
//            $0.elapsedSeconds = 3
//        }
//    }
    
    
    @MainActor
    func testTimerTicks() async {
        let clock = TestClock()

        let store = TestStore(
            initialState: StopWatchFeature.State(),
            reducer: {
                StopWatchFeature()
            }
        ) {
            $0.continuousClock = clock
        }

        // Start the timer
        await store.send(.startTapped) {
            $0.isRunning = true
        }

        // Advance time
        await clock.advance(by: .seconds(3))

        await store.receive(.timerTicked) {
            $0.elapsedSeconds = 1
        }
        await store.receive(.timerTicked) {
            $0.elapsedSeconds = 2
        }
        await store.receive(.timerTicked) {
            $0.elapsedSeconds = 3
        }

        // ✅ STOP THE TIMER (this cancels the long-living effect)
        await store.send(.stopTapped) {
            $0.isRunning = false
        }
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
